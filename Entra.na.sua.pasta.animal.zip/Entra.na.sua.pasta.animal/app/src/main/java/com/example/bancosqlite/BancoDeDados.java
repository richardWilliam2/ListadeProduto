package com.example.bancosqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class BancoDeDados extends SQLiteOpenHelper {
    private final String criaTabela = "CREATE TABLE produto ( "
            + " _id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "nome TEXT NOT NULL, "
            + "preco REAL NOT NULL, "
            + "quantidade INTEGER NOT NULL);";


    //Context serve para saber o ambiente em que o código será executado
    //Version para controlar atualizações futuras do banco
    //factory é utilizado para comandos de SELECT personalizados
    public BancoDeDados(@Nullable Context context, int version) {
        super(context, "bancoNome", null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Executar o comando SQL do criaTabela
        //Observação: se houverem mais comands SQL, executar 1 por vez,
        //ou seja, executar o método execSQL() para cada comando SQL
        db.execSQL(criaTabela);
    }

    //Comando para habilitar a chave estrangeira (FOREING KEY)
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        db.execSQL("PRAGMA foreign_keys=ON");
    }

    //Método para cadastrar (INSERT) um produto
    //Retorna boolean (verdadeiro ou falso) se cadastrou ou não
    public boolean cadastrar(Produto p){
        //Abrir a conexão do nosso banco local
        SQLiteDatabase banco = getWritableDatabase();
        //Passagem de valores para cada coluna da tabela produto
        ContentValues valores = new ContentValues();
        valores.put("nome", p.getNome()); //Nome_da_coluna, valor
        valores.put("preco", p.getPreço());
        valores.put("quantidade", p.getQuantidade());
        //Chamar o comando insert dentro da IF para testar se de certo ou não
        if(banco.insert("produto", null, valores) != -1){
            //Se deu certo, fecha a conexão e retorna true
            banco.close();
            return true;
        }else {
            //Se deu algum erro...
            banco.close();
            return false;
        }
    }
    //Método para atualizar um produto
    //Para atualizar precisamos de um Produto e do codigo
    public boolean atualizar (Produto p, int codigo){
        //Abrir a conexão com o banco local
        SQLiteDatabase banco = getWritableDatabase();
        //Indicar as coluas da tabela e os valores que serão atualizados
        ContentValues valores = new ContentValues();

        valores.put("nome", p.getNome());
        valores.put("preco", p.getPreço());
        valores.put("quantidade", p.getQuantidade());
        //Executar o comando update dentro do IF para testar o retorno
        if (banco.update("produto", valores, "_id=?", new String[]{codigo + ""}) != 0){
            //O comando update indica quantas linhas foram atualizadas
            //Se for diferentes de zero, então atualiou ao menos 1 linha
            banco.close();
            return true;
        }else{
            banco.close();
            return false;
        }
    }
    //Comando para apagar um produto atraves di codigo
    public boolean apagar(int codigo){
        SQLiteDatabase banco = getWritableDatabase();
        if(banco.delete("produto", "_id=?", new String[]{codigo + ""}) != 0){
            banco.close();
            return true;
        }else{
            banco.close();
            return false;
        }
    }
    //Comando para buscar todos os produtos cadastrados
    //Retorna uma lista com todos os objetos produtos da tabela
    public List<Produto> buscarTodos(){
        List<Produto> produtos = new ArrayList<>();
        SQLiteDatabase banco = getWritableDatabase();
        //para receber os dados de todos os produtos da tabela
        //usamos um objeto da classe cursor
        Cursor c = banco.query("produto", null, null, null, null, null, null, null);

        //verificar se tem ao menos um produto cadastrado
        if(c.moveToFirst()){
            //como ja estgá no primeiro, então vamos usar um do while
            //para ler o primeiro produto e adicionar na lista
            do{
                Produto p = new Produto(
                        c.getInt(0), c.getString(1),
                        c.getDouble(2), c.getInt(3));
                produtos.add(p);
            }while (c.moveToNext());
        }
        //apos percorrer o laço, retornamos a lista com todos os produtos
        banco.close();
        return produtos;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
