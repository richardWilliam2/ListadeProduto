package com.example.bancosqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText codigo = findViewById(R.id.campoCodigo);
        EditText nome = findViewById(R.id.campoNome);
        EditText preco = findViewById(R.id.campoPreco);
        EditText quantidade = findViewById(R.id.campoQuantidade);
        Button cadastrar = findViewById(R.id.btCadastrar);
        Button atualizar = findViewById(R.id.btAtualizar);
        Button apagar = findViewById(R.id.btApagar);
        Button listar = findViewById(R.id.btListar);

//codigo do botao atualizar
        atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDeDados bd = new BancoDeDados(MainActivity.this, 1);
                //recupera os valores do produto que foram preenchidos na tela
                Produto p = new Produto(Integer.parseInt(codigo.getText().toString()),
                        nome.getText().toString(),
                        Double.parseDouble(preco.getText().toString()),
                        Integer.parseInt(quantidade.getText().toString()));
                if (bd.atualizar(p, p.getCodigo())) {
                    Toast.makeText(MainActivity.this,
                            "Produto atualizado", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this,
                            "Erro ao atualizar", Toast.LENGTH_SHORT).show();
                }
            }
        });
//Codigo do botao apagar
        apagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDeDados bd = new BancoDeDados(MainActivity.this, 1);
                if (bd.apagar(Integer.parseInt(codigo.getText().toString()))){
                    Toast.makeText(MainActivity.this,
                            "Produto removido", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,
                            "Erro ao remover", Toast.LENGTH_SHORT).show();
                }
            }
        });
//botao listar
        listar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,
                        TelaListar.class));
            }
        });



        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoDeDados bd = new BancoDeDados(MainActivity.this, 1);
                Produto p = new Produto(0, nome.getText().toString(),
                        Double.parseDouble(preco.getText().toString()),
                        Integer.parseInt(quantidade.getText().toString()));
                if(bd.cadastrar(p)){
                    Toast.makeText(MainActivity.this,
                            "Produto cadastrado", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,
                            "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}