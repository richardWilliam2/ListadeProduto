package com.example.bancosqlite;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class TelaListar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_listar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ListView listView = findViewById(R.id.listView);
        BancoDeDados banco = new BancoDeDados(TelaListar.this, 1);
//executar o método buscarTodos da classe BancoDeDados
//e recuperar todos os proditps cadastrados em uma list
        List<Produto> listaProdutos = banco.buscarTodos();
//criar um adapter para que seja possivel exibir os produtos na lisview
        ArrayAdapter<Produto> adapter = new ArrayAdapter<>(
                TelaListar.this,
                android.R.layout.simple_list_item_1,
                listaProdutos); //lista de produtos a ser exibida
        listView.setAdapter(adapter);// Sou gabriel gosto  de penis e meu cu n é virgem kakakakak

        // Evento do ListView para detectar quando é clicado sobre um item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Recuperar o produto que foi clicadoi
                Produto p = listaProdutos.get(position);
                AlertDialog.Builder dialog = new AlertDialog.Builder(TelaListar.this);
                dialog.setTitle("Detalhes do produto");
                dialog.setMessage(p.toString());
                //consigurar o botão PositiveButton (á direita)
                dialog.setPositiveButton("Apagar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        banco.apagar(p.getCodigo());//Remove do bando de dados
                        //Remover da lista listaP
                        listaProdutos.remove(p);
                        adapter.notifyDataSetChanged();
                    }
                });
                dialog.setNeutralButton("cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //fecha o dialog
                        dialog.cancel();
                    }
                });
                //Depois de fazer a configuranção do AlertDialog, agora precisamos/~/~/~/~/~/~/~/~/
                //montar (create á partir do build) e exibir
                AlertDialog alertDialog = dialog.create();
                alertDialog.show();
            }
        });

    }
}