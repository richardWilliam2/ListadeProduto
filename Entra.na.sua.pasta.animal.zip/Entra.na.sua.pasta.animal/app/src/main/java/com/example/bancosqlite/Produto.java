package com.example.bancosqlite;

public class Produto {
    //atributos
    private int codigo;
    private String nome;
    private double preco;
    private int quantidade;

//Construtor (Atalho: Alt insert)

    public Produto(int codigo, String nome, double preço, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preço;
        this.quantidade = quantidade;
    }
    //Construtor vazio - será utilizado no webservice
    public Produto(){}

//Métodos getters e setters (Atalho: Alt Insert)


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreço() {
        return preco;
    }

    public void setPreço(double preço) {
        this.preco = preço;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    //Sobreescrever o metódo toString() para formatar como o
//objeto da classe Produto será exibido quando for uma String
    @Override
    public String toString(){
        return "Cód: " + codigo + " Nome: " + nome + " R$ " +
                preco + " Quantidade: " + quantidade;
    }

}
